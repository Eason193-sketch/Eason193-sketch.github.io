#include "ros/ros.h"
#include "geometry_msgs/PoseStamped.h"  
#include "std_msgs/String.h"
#include "dumb/takeland.h"
#include <cmath>
typedef enum {
    SETOFF,
    CATCH,
    TOSS,
    OBTAIN,
    LAND
}State_general;
// Create a message object
geometry_msgs::PoseStamped msg;
State_general state;
std::map<std::string, State_general> STATE = {
  {"SETOFF", SETOFF},
  {"CATCH", CATCH},
  {"TOSS", TOSS},
  {"OBTAIN", OBTAIN},
  {"LAND", LAND}
};

void stateCallback(const std_msgs::String::ConstPtr& msg_p)
{
  state=STATE[msg_p->data];
  switch(state)
  {
    case SETOFF:
    ROS_INFO("Setoff");
    msg.header.frame_id = "world";
    msg.pose.position.x = 1.5;
    msg.pose.position.y = 0.0;
    msg.pose.position.z = 1.5;
    msg.pose.orientation.x = 0.0;
    msg.pose.orientation.y = 0.0;
    msg.pose.orientation.z = sin(90.0 * M_PI / 360.0);
    msg.pose.orientation.w = cos(90.0 * M_PI / 360.0);
    break;
    case CATCH:
    ROS_INFO("CATCH");
    msg.header.frame_id = "world";
    msg.pose.position.x = 1.5;
    msg.pose.position.y = 0.0;
    msg.pose.position.z = 1.5;
    msg.pose.orientation.x = 0.0;
    msg.pose.orientation.y = 0.0;
    msg.pose.orientation.z = sin(90.0 * M_PI / 360.0);
    msg.pose.orientation.w = cos(90.0 * M_PI / 360.0);
    break;
  }
}


int main(int argc, char **argv)
{
  ros::init(argc, argv, "dumb");
  ros::NodeHandle n;
  ros::Publisher pos_pub = n.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 1000);
  ros::Publisher takeoff_land_pub = n.advertise<dumb::takeland>("/general/status", 1000);
  ros::Subscriber state_sub=n.subscribe("/general/status", 1000, stateCallback);
  ros::Rate loop_rate(20.0);
  while(ros::ok())
  {
    dumb::takeland msg;
    msg.takeoff_land_cmd = 1;
    takeoff_land_pub.publish("takeoff_land_cmd: 1");
  }
}