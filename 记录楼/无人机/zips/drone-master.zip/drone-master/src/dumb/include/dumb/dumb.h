typedef enum {
    SETOFF,
    CATCH,
    TOSS,
    OBTAIN,
    LAND
}State_general;